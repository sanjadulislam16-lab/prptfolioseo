
  # Create Professional Portfolio (Copy)

  This is a code bundle for Create Professional Portfolio (Copy). The original project is available at https://www.figma.com/design/byhhI1DqZkdqNNqjNb5wHz/Create-Professional-Portfolio--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  