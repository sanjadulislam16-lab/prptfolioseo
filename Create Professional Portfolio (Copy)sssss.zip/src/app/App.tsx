import "../styles/fonts.css";
import { HelmetProvider, Helmet } from "react-helmet-async";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Skills } from "./components/Skills";
import { Projects } from "./components/Projects";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <HelmetProvider>
      <Helmet>
        <title>Sanjadul Islam Sun — Full Stack Developer & UI/UX Designer</title>
        <meta name="description" content="Portfolio of Sanjadul Islam Sun — Full Stack Web Developer, App Developer, UI/UX Designer, and AI Vibe Coder from Jhikargacha, Jashore, Bangladesh." />
        <meta name="keywords" content="Sanjadul Islam Sun, Full Stack Developer, Web Developer, UI/UX Designer, React Developer, Flutter, Bangladesh, Khulna, portfolio" />
        <meta name="author" content="Sanjadul Islam Sun" />
        <meta name="robots" content="index, follow" />

        {/* Open Graph (Facebook, LinkedIn preview) */}
        <meta property="og:title" content="Sanjadul Islam Sun — Full Stack Developer" />
        <meta property="og:description" content="Full Stack Web Developer, App Developer & UI/UX Designer from Bangladesh. Building stunning digital experiences." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://sun.dev" />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Sanjadul Islam Sun — Full Stack Developer" />
        <meta name="twitter:description" content="Full Stack Web Developer, App Developer & UI/UX Designer from Bangladesh." />

        {/* Canonical */}
        <link rel="canonical" href="https://sun.dev" />
      </Helmet>

      <div className="min-h-screen bg-[#050a14] text-[#e8edf5] overflow-x-hidden">
        <style>{`
          ::-webkit-scrollbar { width: 4px; }
          ::-webkit-scrollbar-track { background: #050a14; }
          ::-webkit-scrollbar-thumb { background: #00d4ff30; border-radius: 4px; }
          ::-webkit-scrollbar-thumb:hover { background: #00d4ff60; }
          html { scroll-behavior: smooth; }
        `}</style>

        <Navbar />
        <Hero />

        <div className="max-w-7xl mx-auto px-6">
          <div className="h-px bg-gradient-to-r from-transparent via-[#00d4ff]/15 to-transparent" />
        </div>

        <About />

        <div className="max-w-7xl mx-auto px-6">
          <div className="h-px bg-gradient-to-r from-transparent via-[#00d4ff]/15 to-transparent" />
        </div>

        <Skills />

        <div className="max-w-7xl mx-auto px-6">
          <div className="h-px bg-gradient-to-r from-transparent via-[#00d4ff]/15 to-transparent" />
        </div>

        <Projects />

        <div className="max-w-7xl mx-auto px-6">
          <div className="h-px bg-gradient-to-r from-transparent via-[#00d4ff]/15 to-transparent" />
        </div>

        <Contact />

        <Footer />
      </div>
    </HelmetProvider>
  );
}
