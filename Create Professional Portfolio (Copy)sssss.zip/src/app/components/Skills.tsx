import { motion } from "motion/react";

const skillCategories = [
  {
    category: "Frontend",
    color: "#00d4ff",
    skills: [
      { name: "React.js", level: 90 },
      { name: "Next.js", level: 82 },
      { name: "TypeScript", level: 78 },
      { name: "Tailwind CSS", level: 95 },
      { name: "HTML & CSS", level: 97 },
    ],
  },
  {
    category: "Backend",
    color: "#a78bfa",
    skills: [
      { name: "Node.js", level: 80 },
      { name: "Express.js", level: 78 },
      { name: "MongoDB", level: 75 },
      { name: "Firebase", level: 72 },
      { name: "REST APIs", level: 85 },
    ],
  },
  {
    category: "Design & Tools",
    color: "#34d399",
    skills: [
      { name: "Figma", level: 88 },
      { name: "UI/UX Design", level: 85 },
      { name: "Git & GitHub", level: 82 },
      { name: "AI Vibe Coding", level: 90 },
      { name: "Flutter", level: 65 },
    ],
  },
];

const techBadges = [
  "React", "Next.js", "TypeScript", "Node.js", "Express", "MongoDB",
  "Tailwind CSS", "Figma", "Flutter", "Firebase", "Git", "Python",
  "JavaScript", "HTML5", "CSS3", "REST API",
];

function SkillBar({ name, level, color, index }: { name: string; level: number; color: string; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      className="mb-5"
    >
      <div className="flex justify-between mb-2">
        <span className="text-[#e8edf5] text-sm font-medium">{name}</span>
        <span className="text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", color }}>{level}%</span>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: index * 0.07 + 0.3, ease: "easeOut" }}
          className="h-full rounded-full"
          style={{
            background: `linear-gradient(90deg, ${color}88, ${color})`,
            boxShadow: `0 0 10px ${color}60`,
          }}
        />
      </div>
    </motion.div>
  );
}

export function Skills() {
  return (
    <section id="skills" className="py-28 relative overflow-hidden">
      <div className="absolute left-0 top-0 w-80 h-80 bg-[#00d4ff]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-16"
        >
          <span className="text-[#00d4ff] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>02.</span>
          <h2 className="text-white" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 700 }}>
            Skills & Expertise
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-[#00d4ff]/20 to-transparent" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((cat, ci) => (
            <motion.div
              key={cat.category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: ci * 0.1 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="p-6 rounded-3xl relative overflow-hidden"
              style={{
                background: `linear-gradient(135deg, rgba(255,255,255,0.07) 0%, ${cat.color}08 100%)`,
                backdropFilter: "blur(24px) saturate(1.8)",
                WebkitBackdropFilter: "blur(24px) saturate(1.8)",
                border: `1px solid ${cat.color}25`,
                boxShadow: `0 4px 32px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.1), 0 0 0 0.5px ${cat.color}10`,
              }}
            >
              {/* shimmer */}
              <span className="absolute inset-x-4 top-0 h-px rounded-full"
                style={{ background: `linear-gradient(90deg, transparent, ${cat.color}50, transparent)` }} />

              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold"
                  style={{
                    background: `linear-gradient(135deg, ${cat.color}25, ${cat.color}10)`,
                    border: `1px solid ${cat.color}40`,
                    color: cat.color,
                    fontFamily: "'JetBrains Mono', monospace",
                    boxShadow: `inset 0 1px 0 rgba(255,255,255,0.15)`,
                  }}
                >
                  {"{"}
                </div>
                <h3 className="font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", color: cat.color }}>
                  {cat.category}
                </h3>
              </div>
              {cat.skills.map((skill, i) => (
                <SkillBar key={skill.name} name={skill.name} level={skill.level} color={cat.color} index={i} />
              ))}
            </motion.div>
          ))}
        </div>

        {/* Tech badges */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-[#7a8fa8] text-sm mb-6" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            {"// technologies I work with"}
          </p>
          <div className="flex flex-wrap gap-2 justify-center">
            {techBadges.map((tech, i) => (
              <motion.span
                key={tech}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
                whileHover={{ scale: 1.08, y: -2 }}
                className="px-3 py-1.5 rounded-xl text-xs text-[#a0b4c8] cursor-default relative overflow-hidden"
                style={{
                  fontFamily: "'JetBrains Mono', monospace",
                  background: "linear-gradient(135deg, rgba(255,255,255,0.06), rgba(0,212,255,0.04))",
                  backdropFilter: "blur(16px)",
                  WebkitBackdropFilter: "blur(16px)",
                  border: "1px solid rgba(0,212,255,0.15)",
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.08)",
                }}
              >
                {tech}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
