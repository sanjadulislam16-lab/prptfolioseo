import { useState } from "react";
import { motion } from "motion/react";
import { Send, MapPin, Phone, Mail, CheckCircle } from "lucide-react";
import { projectId, publicAnonKey } from "/utils/supabase/info";

const glass = {
  background: "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(0,212,255,0.04) 100%)",
  backdropFilter: "blur(24px) saturate(1.8)",
  WebkitBackdropFilter: "blur(24px) saturate(1.8)",
  border: "1px solid rgba(0,212,255,0.15)",
  boxShadow: "0 4px 24px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.1)",
};

const inputStyle = {
  background: "rgba(255,255,255,0.04)",
  backdropFilter: "blur(12px)",
  WebkitBackdropFilter: "blur(12px)",
  border: "1px solid rgba(0,212,255,0.15)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.06)",
};

export function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-b7afe9fe/contact`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${publicAnonKey}` },
          body: JSON.stringify(form),
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send message");
      setSubmitted(true);
    } catch (err: any) {
      console.error("Contact form error:", err);
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contact" className="py-28 relative overflow-hidden">
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-80 h-80 bg-[#7c3aed]/8 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-6"
        >
          <span className="text-[#00d4ff] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>04.</span>
          <h2 className="text-white" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 700 }}>
            Get In Touch
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-[#00d4ff]/20 to-transparent" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-[#7a8fa8] text-sm mb-14 ml-12 max-w-lg"
        >
          Open to new opportunities, collaborations, or just a friendly chat. My inbox is always open!
        </motion.p>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2 flex flex-col gap-4"
          >
            {[
              { icon: MapPin, title: "Location", lines: ["Jhikargacha, Jashore", "Post Office: 7420, Bangladesh"] },
              { icon: Phone, title: "Phone", lines: ["+880 1608-474429"] },
              { icon: Mail, title: "Email", lines: ["eng.sanjadulislamsun@gmail.com"] },
            ].map(({ icon: Icon, title, lines }) => (
              <motion.div
                key={title}
                whileHover={{ scale: 1.02, y: -2 }}
                className="flex gap-4 p-5 rounded-2xl relative overflow-hidden"
                style={glass}
              >
                <span className="absolute inset-x-4 top-0 h-px rounded-full"
                  style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.3), transparent)" }} />
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: "linear-gradient(135deg, rgba(0,212,255,0.2), rgba(124,58,237,0.15))",
                    border: "1px solid rgba(0,212,255,0.25)",
                    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.15)",
                  }}
                >
                  <Icon size={18} className="text-[#00d4ff]" />
                </div>
                <div>
                  <p className="text-[#00d4ff] text-xs mb-1" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{title}</p>
                  {lines.map((line) => (
                    <p key={line} className="text-[#e8edf5] text-sm font-medium">{line}</p>
                  ))}
                </div>
              </motion.div>
            ))}

            <motion.div
              whileHover={{ scale: 1.02, y: -2 }}
              className="p-5 rounded-2xl relative overflow-hidden mt-2"
              style={{
                background: "linear-gradient(135deg, rgba(0,212,255,0.1) 0%, rgba(124,58,237,0.1) 100%)",
                backdropFilter: "blur(24px) saturate(1.8)",
                WebkitBackdropFilter: "blur(24px) saturate(1.8)",
                border: "1px solid rgba(0,212,255,0.2)",
                boxShadow: "0 4px 24px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.12)",
              }}
            >
              <span className="absolute inset-x-4 top-0 h-px rounded-full"
                style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.5), rgba(124,58,237,0.4), transparent)" }} />
              <p className="text-[#00d4ff] text-xs mb-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{"// availability"}</p>
              <p className="text-white text-sm font-medium mb-1">Available Now</p>
              <p className="text-[#7a8fa8] text-xs">Open for freelance projects, internships, and full-time roles.</p>
            </motion.div>
          </motion.div>

          {/* Contact form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center gap-4 p-12 rounded-3xl text-center relative overflow-hidden"
                style={glass}
              >
                <span className="absolute inset-x-8 top-0 h-px rounded-full"
                  style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), transparent)" }} />
                <CheckCircle size={48} className="text-[#00d4ff]" />
                <h3 className="text-white" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>Message Sent!</h3>
                <p className="text-[#7a8fa8] text-sm max-w-xs">Thanks for reaching out. I'll get back to you within 24 hours.</p>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => { setSubmitted(false); setForm({ name: "", email: "", subject: "", message: "" }); }}
                  className="mt-2 px-5 py-2 rounded-2xl text-sm text-[#00d4ff] relative overflow-hidden"
                  style={{
                    background: "rgba(0,212,255,0.08)",
                    border: "1px solid rgba(0,212,255,0.3)",
                    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.1)",
                  }}
                >
                  Send Another
                </motion.button>
              </motion.div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="p-8 rounded-3xl space-y-5 relative overflow-hidden"
                style={glass}
              >
                <span className="absolute inset-x-8 top-0 h-px rounded-full"
                  style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), transparent)" }} />

                <div className="grid sm:grid-cols-2 gap-5">
                  {[
                    { key: "name", label: "Your Name", placeholder: "Sanjadul Islam" },
                    { key: "email", label: "Email Address", placeholder: "you@example.com" },
                  ].map(({ key, label, placeholder }) => (
                    <div key={key}>
                      <label className="block text-xs text-[#00d4ff] mb-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{label}</label>
                      <input
                        type={key === "email" ? "email" : "text"}
                        required
                        placeholder={placeholder}
                        value={form[key as keyof typeof form]}
                        onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                        className="w-full px-4 py-3 rounded-2xl text-[#e8edf5] text-sm placeholder-[#7a8fa8]/50 focus:outline-none transition-all"
                        style={{
                          ...inputStyle,
                          color: "#e8edf5",
                        }}
                        onFocus={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.5)"}
                        onBlur={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.15)"}
                      />
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block text-xs text-[#00d4ff] mb-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>Subject</label>
                  <input
                    type="text"
                    required
                    placeholder="Project Inquiry / Collaboration"
                    value={form.subject}
                    onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                    className="w-full px-4 py-3 rounded-2xl text-[#e8edf5] text-sm placeholder-[#7a8fa8]/50 focus:outline-none transition-all"
                    style={inputStyle}
                    onFocus={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.5)"}
                    onBlur={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.15)"}
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#00d4ff] mb-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>Message</label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Tell me about your project or idea..."
                    value={form.message}
                    onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                    className="w-full px-4 py-3 rounded-2xl text-[#e8edf5] text-sm placeholder-[#7a8fa8]/50 focus:outline-none transition-all resize-none"
                    style={inputStyle}
                    onFocus={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.5)"}
                    onBlur={(e) => e.target.style.border = "1px solid rgba(0,212,255,0.15)"}
                  />
                </div>

                {error && <p className="text-red-400 text-xs px-1">{error}</p>}

                <motion.button
                  type="submit"
                  disabled={loading}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  className="w-full py-3.5 rounded-2xl font-semibold text-sm text-white disabled:opacity-70 flex items-center justify-center gap-2 relative overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, rgba(0,212,255,0.45) 0%, rgba(0,150,200,0.5) 100%)",
                    backdropFilter: "blur(16px)",
                    border: "1px solid rgba(0,212,255,0.5)",
                    boxShadow: "0 4px 24px rgba(0,212,255,0.25), inset 0 1px 0 rgba(255,255,255,0.2)",
                  }}
                >
                  <span className="absolute inset-x-6 top-0 h-px rounded-full"
                    style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent)" }} />
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send size={15} />
                      Send Message
                    </>
                  )}
                </motion.button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
