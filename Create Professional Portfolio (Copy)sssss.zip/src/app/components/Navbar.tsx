import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Code2 } from "lucide-react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

/* iOS 26 Liquid Glass nav pill */
function LiquidNavItem({
  link,
  active,
  onClick,
}: {
  link: { label: string; href: string };
  active: boolean;
  onClick: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const [ripple, setRipple] = useState<{ x: number; y: number } | null>(null);
  const ref = useRef<HTMLAnchorElement>(null);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const rect = ref.current?.getBoundingClientRect();
    if (rect) {
      setRipple({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      setTimeout(() => setRipple(null), 600);
    }
    onClick();
  };

  return (
    <a
      ref={ref}
      href={link.href}
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative px-4 py-2 text-sm rounded-2xl overflow-hidden select-none"
      style={{
        fontFamily: "'Inter', sans-serif",
        color: active ? "#ffffff" : hovered ? "#e8edf5" : "#7a8fa8",
        transition: "color 0.25s",
      }}
    >
      {/* Glass pill background */}
      <AnimatePresence>
        {(active || hovered) && (
          <motion.span
            layoutId={active ? "liquid-pill" : undefined}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="absolute inset-0 rounded-2xl"
            style={{
              background: active
                ? "linear-gradient(135deg, rgba(0,212,255,0.22) 0%, rgba(124,58,237,0.14) 100%)"
                : "rgba(255,255,255,0.06)",
              backdropFilter: "blur(20px) saturate(1.8)",
              WebkitBackdropFilter: "blur(20px) saturate(1.8)",
              border: active
                ? "1px solid rgba(0,212,255,0.35)"
                : "1px solid rgba(255,255,255,0.1)",
              boxShadow: active
                ? "0 4px 24px rgba(0,212,255,0.18), inset 0 1px 0 rgba(255,255,255,0.2), inset 0 -1px 0 rgba(0,0,0,0.1)"
                : "inset 0 1px 0 rgba(255,255,255,0.12)",
            }}
          />
        )}
      </AnimatePresence>

      {/* Shimmer highlight on top */}
      {active && (
        <span
          className="absolute inset-x-2 top-0 h-px rounded-full"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.6), transparent)",
          }}
        />
      )}

      {/* Liquid ripple on click */}
      <AnimatePresence>
        {ripple && (
          <motion.span
            key={`${ripple.x}-${ripple.y}`}
            initial={{ width: 0, height: 0, opacity: 0.5 }}
            animate={{ width: 120, height: 120, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute rounded-full pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
              transform: "translate(-50%, -50%)",
              background: "radial-gradient(circle, rgba(0,212,255,0.4) 0%, transparent 70%)",
            }}
          />
        )}
      </AnimatePresence>

      <span className="relative z-10 font-medium">{link.label}</span>
    </a>
  );
}

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("Home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
    >
      {/* Liquid Glass navbar bar */}
      <div
        className="mx-4 mt-3 rounded-3xl overflow-hidden"
        style={{
          background: scrolled
            ? "linear-gradient(135deg, rgba(10,22,40,0.75) 0%, rgba(5,10,20,0.85) 100%)"
            : "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(0,212,255,0.05) 100%)",
          backdropFilter: "blur(32px) saturate(2)",
          WebkitBackdropFilter: "blur(32px) saturate(2)",
          border: "1px solid rgba(0,212,255,0.15)",
          boxShadow: scrolled
            ? "0 8px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08), 0 0 0 0.5px rgba(0,212,255,0.1)"
            : "0 4px 24px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.12)",
        }}
      >
        {/* Top shimmer line */}
        <div
          className="absolute top-0 left-8 right-8 h-px rounded-full"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), rgba(255,255,255,0.2), rgba(0,212,255,0.4), transparent)",
          }}
        />

        <div className="px-5 py-3 flex items-center justify-between">
          {/* Logo */}
          <motion.a
            href="#home"
            className="flex items-center gap-2 group"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, rgba(0,212,255,0.25), rgba(124,58,237,0.2))",
                backdropFilter: "blur(12px)",
                border: "1px solid rgba(0,212,255,0.3)",
                boxShadow: "0 2px 12px rgba(0,212,255,0.2), inset 0 1px 0 rgba(255,255,255,0.2)",
              }}
            >
              <Code2 size={17} className="text-[#00d4ff]" />
            </div>
            <span
              className="text-white hidden sm:block"
              style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "14px", fontWeight: 700 }}
            >
              sun<span className="text-[#00d4ff]">.dev</span>
            </span>
          </motion.a>

          {/* Nav links with liquid glass */}
          <div className="hidden md:flex items-center gap-1 p-1 rounded-2xl"
            style={{
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            {navLinks.map((link) => (
              <LiquidNavItem
                key={link.label}
                link={link}
                active={active === link.label}
                onClick={() => setActive(link.label)}
              />
            ))}
          </div>

          {/* Hire Me — liquid glass button */}
          <motion.a
            href="#contact"
            className="hidden md:flex items-center px-5 py-2 rounded-2xl text-sm font-semibold text-white overflow-hidden relative"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            style={{
              background: "linear-gradient(135deg, rgba(0,212,255,0.35) 0%, rgba(0,150,200,0.4) 100%)",
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
              border: "1px solid rgba(0,212,255,0.45)",
              boxShadow: "0 4px 20px rgba(0,212,255,0.25), inset 0 1px 0 rgba(255,255,255,0.25)",
            }}
          >
            <span
              className="absolute inset-x-3 top-0 h-px rounded-full"
              style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent)" }}
            />
            Hire Me
          </motion.a>

          {/* Mobile menu button */}
          <motion.button
            className="md:hidden p-2 rounded-xl"
            onClick={() => setMenuOpen((v) => !v)}
            whileTap={{ scale: 0.9 }}
            style={{
              background: "rgba(0,212,255,0.1)",
              border: "1px solid rgba(0,212,255,0.2)",
            }}
          >
            {menuOpen ? <X size={20} className="text-[#00d4ff]" /> : <Menu size={20} className="text-[#00d4ff]" />}
          </motion.button>
        </div>
      </div>

      {/* Mobile menu — liquid glass */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 320, damping: 28 }}
            className="mx-4 mt-2 rounded-3xl overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(10,22,40,0.82) 0%, rgba(5,10,20,0.9) 100%)",
              backdropFilter: "blur(40px) saturate(2)",
              WebkitBackdropFilter: "blur(40px) saturate(2)",
              border: "1px solid rgba(0,212,255,0.15)",
              boxShadow: "0 16px 48px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08)",
            }}
          >
            <div
              className="absolute top-0 left-8 right-8 h-px"
              style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), transparent)" }}
            />
            <div className="px-4 py-4 flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => { setActive(link.label); setMenuOpen(false); }}
                  className="py-3 px-4 rounded-2xl text-sm font-medium transition-all duration-200"
                  style={{
                    color: active === link.label ? "#00d4ff" : "#7a8fa8",
                    background: active === link.label ? "rgba(0,212,255,0.12)" : "transparent",
                    border: active === link.label ? "1px solid rgba(0,212,255,0.2)" : "1px solid transparent",
                  }}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setMenuOpen(false)}
                className="mt-1 py-3 text-center rounded-2xl text-sm font-semibold text-white"
                style={{
                  background: "linear-gradient(135deg, rgba(0,212,255,0.35), rgba(0,150,200,0.4))",
                  border: "1px solid rgba(0,212,255,0.4)",
                  boxShadow: "0 4px 16px rgba(0,212,255,0.2), inset 0 1px 0 rgba(255,255,255,0.2)",
                }}
              >
                Hire Me
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
