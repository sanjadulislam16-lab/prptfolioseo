import { motion } from "motion/react";
import { GraduationCap, MapPin, Phone, Mail, Calendar, Cpu } from "lucide-react";

const glass = {
  background: "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(0,212,255,0.04) 100%)",
  backdropFilter: "blur(24px) saturate(1.8)",
  WebkitBackdropFilter: "blur(24px) saturate(1.8)",
  border: "1px solid rgba(0,212,255,0.15)",
  boxShadow: "0 4px 24px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.1)",
};

function InfoCard({
  icon: Icon,
  label,
  value,
  delay,
}: {
  icon: typeof MapPin;
  label: string;
  value: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ scale: 1.02, y: -2 }}
      className="flex items-start gap-3 p-4 rounded-2xl group relative overflow-hidden"
      style={glass}
    >
      {/* shimmer top */}
      <span className="absolute inset-x-4 top-0 h-px rounded-full"
        style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.3), transparent)" }} />
      <div
        className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{
          background: "linear-gradient(135deg, rgba(0,212,255,0.2), rgba(124,58,237,0.15))",
          border: "1px solid rgba(0,212,255,0.25)",
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.15)",
        }}
      >
        <Icon size={16} className="text-[#00d4ff]" />
      </div>
      <div>
        <p className="text-[#00d4ff] text-xs mb-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
          {label}
        </p>
        <p className="text-white text-sm font-medium">{value}</p>
      </div>
    </motion.div>
  );
}

export function About() {
  return (
    <section id="about" className="py-28 relative overflow-hidden">
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-[#7c3aed]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-16"
        >
          <span className="text-[#00d4ff] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>01.</span>
          <h2 className="text-white" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 700 }}>
            About Me
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-[#00d4ff]/20 to-transparent" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-[#7a8fa8] leading-relaxed mb-6"
              style={{ fontSize: "0.97rem" }}
            >
              আমি একজন passionate full stack developer এবং UI/UX designer যিনি
              stunning digital experiences তৈরি করতে ভালোবাসেন। আমি Mangrove
              Institute of Science and Technology, Khulna-তে Diploma in
              Engineering-এর 5th semester-এ পড়ছি।
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-[#7a8fa8] leading-relaxed mb-10"
              style={{ fontSize: "0.97rem" }}
            >
              I build complete web applications and mobile apps using modern
              technologies, design beautiful interfaces, and leverage AI tools
              for vibe coding.
            </motion.p>

            {/* Stats — liquid glass */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-3 gap-4 mb-10"
            >
              {[
                { value: "15+", label: "Projects" },
                { value: "5th", label: "Semester" },
                { value: "3+", label: "Years Coding" },
              ].map((stat) => (
                <motion.div
                  key={stat.label}
                  whileHover={{ scale: 1.05, y: -3 }}
                  className="text-center p-4 rounded-2xl relative overflow-hidden"
                  style={glass}
                >
                  <span className="absolute inset-x-3 top-0 h-px rounded-full"
                    style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), transparent)" }} />
                  <div className="text-[#00d4ff] mb-1" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "1.8rem", fontWeight: 800 }}>
                    {stat.value}
                  </div>
                  <div className="text-[#7a8fa8] text-xs">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          <div className="grid gap-3">
            <InfoCard icon={GraduationCap} label="Education" value="Diploma in Engineering — 5th Semester" delay={0} />
            <InfoCard icon={Cpu} label="Institute" value="Mangrove Institute of Science and Technology, Khulna" delay={0.05} />
            <InfoCard icon={MapPin} label="Address" value="Jhikargacha, Jashore — Post Office 7420" delay={0.1} />
            <InfoCard icon={Phone} label="Phone" value="01608474429" delay={0.15} />
            <InfoCard icon={Mail} label="Email" value="eng.sanjadulislamsun@gmail.com" delay={0.2} />
            <InfoCard icon={Calendar} label="Status" value="Open to Freelance & Full-time Opportunities" delay={0.25} />
          </div>
        </div>
      </div>
    </section>
  );
}
