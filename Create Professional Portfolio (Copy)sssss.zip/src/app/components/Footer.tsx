import { motion } from "motion/react";
import { Code2, Heart, Github, Linkedin, Mail, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="py-12 relative overflow-hidden">
      {/* Liquid glass footer bar */}
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-3xl p-8 relative overflow-hidden mb-6"
          style={{
            background: "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(0,212,255,0.04) 100%)",
            backdropFilter: "blur(32px) saturate(1.8)",
            WebkitBackdropFilter: "blur(32px) saturate(1.8)",
            border: "1px solid rgba(0,212,255,0.15)",
            boxShadow: "0 4px 32px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.1)",
          }}
        >
          {/* shimmer */}
          <span className="absolute inset-x-8 top-0 h-px rounded-full"
            style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.4), rgba(255,255,255,0.2), rgba(0,212,255,0.4), transparent)" }} />

          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, rgba(0,212,255,0.25), rgba(124,58,237,0.2))",
                  border: "1px solid rgba(0,212,255,0.3)",
                  boxShadow: "0 2px 12px rgba(0,212,255,0.2), inset 0 1px 0 rgba(255,255,255,0.2)",
                }}
              >
                <Code2 size={17} className="text-[#00d4ff]" />
              </div>
              <div>
                <div className="text-white text-sm" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>
                  Sanjadul Islam Sun
                </div>
                <div className="text-[#7a8fa8] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  Full Stack Developer & UI/UX Designer
                </div>
              </div>
            </div>

            <p className="text-[#7a8fa8] text-xs flex items-center gap-1.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              Built with <Heart size={11} className="text-[#00d4ff] fill-[#00d4ff]" /> React + Tailwind CSS
            </p>

            {/* Social icons — liquid glass */}
            <div className="flex gap-2">
              {[
                { icon: Github, href: "https://github.com/sanjadulislam16-lab", label: "GitHub" },
                { icon: Linkedin, href: "https://www.linkedin.com/in/sanjadul-islam-sun-339841401/", label: "LinkedIn" },
                { icon: Mail, href: "mailto:eng.sanjadulislamsun@gmail.com", label: "Email" },
                { icon: Phone, href: "tel:+8801608474429", label: "Phone" },
              ].map(({ icon: Icon, href, label }) => (
                <motion.a
                  key={label}
                  href={href}
                  aria-label={label}
                  whileHover={{ scale: 1.12, y: -2 }}
                  whileTap={{ scale: 0.92 }}
                  className="w-10 h-10 rounded-2xl flex items-center justify-center relative overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, rgba(255,255,255,0.08), rgba(0,212,255,0.05))",
                    backdropFilter: "blur(16px)",
                    border: "1px solid rgba(0,212,255,0.18)",
                    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.12)",
                    color: "#7a8fa8",
                  }}
                >
                  <Icon size={15} />
                </motion.a>
              ))}
            </div>
          </div>
        </motion.div>

        <div className="text-center">
          <p className="text-[#7a8fa8] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            © 2024 Sanjadul Islam Sun. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
