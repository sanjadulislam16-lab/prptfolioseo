import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Download, ArrowDown, Github, Linkedin, Mail, X } from "lucide-react";
import myPhoto from "@/imports/IMG_0597-1.jpeg";
import cvPdf from "@/imports/Sanjadul_CV.pdf";
import cvImage from "@/imports/Sanjadul_CV_Image.png";

const roles = [
  "Full Stack Web Developer",
  "App Developer",
  "UI/UX Designer",
  "AI Vibe Coder",
];

function TypewriterText({ texts }: { texts: string[] }) {
  const [display, setDisplay] = useState("");
  const [roleIdx, setRoleIdx] = useState(0);
  const [phase, setPhase] = useState<"typing" | "pausing" | "deleting">("typing");
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    const current = texts[roleIdx];
    if (phase === "typing") {
      if (display.length < current.length) {
        timeoutRef.current = setTimeout(() => setDisplay(current.slice(0, display.length + 1)), 60);
      } else {
        timeoutRef.current = setTimeout(() => setPhase("pausing"), 1800);
      }
    } else if (phase === "pausing") {
      timeoutRef.current = setTimeout(() => setPhase("deleting"), 300);
    } else {
      if (display.length > 0) {
        timeoutRef.current = setTimeout(() => setDisplay(display.slice(0, -1)), 35);
      } else {
        setRoleIdx((i) => (i + 1) % texts.length);
        setPhase("typing");
      }
    }
    return () => clearTimeout(timeoutRef.current);
  }, [display, phase, roleIdx, texts]);

  return (
    <span>
      {display}
      <span className="animate-pulse text-[#00d4ff]">|</span>
    </span>
  );
}

function FloatingOrb({ className }: { className: string }) {
  return <div className={`absolute rounded-full blur-3xl opacity-20 animate-pulse ${className}`} />;
}

async function downloadCV() {
  try {
    const res = await fetch(cvImage);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Sanjadul_Islam_Sun_CV.jpg";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch {
    window.open(cvImage, "_blank");
  }
}

export function Hero() {
  const [cvOpen, setCvOpen] = useState(false);

  return (
    <>
      {/* CV Preview Modal */}
      <AnimatePresence>
        {cvOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4"
            style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(12px)" }}
            onClick={() => setCvOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 28 }}
              className="relative max-w-2xl w-full rounded-3xl overflow-hidden"
              style={{
                background: "linear-gradient(135deg, rgba(10,22,40,0.95), rgba(5,10,20,0.98))",
                border: "1px solid rgba(0,212,255,0.2)",
                boxShadow: "0 24px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.08)",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <span className="absolute inset-x-8 top-0 h-px rounded-full"
                style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.5), transparent)" }} />

              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-[#00d4ff]/10">
                <span className="text-white text-sm font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  Sanjadul Islam Sun — CV
                </span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={downloadCV}
                    className="flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-semibold text-white relative overflow-hidden"
                    style={{
                      background: "linear-gradient(135deg, rgba(0,212,255,0.4), rgba(0,150,200,0.5))",
                      border: "1px solid rgba(0,212,255,0.4)",
                      boxShadow: "0 2px 12px rgba(0,212,255,0.2), inset 0 1px 0 rgba(255,255,255,0.15)",
                    }}
                  >
                    <Download size={12} />
                    Download CV
                  </button>
                  <button
                    onClick={() => setCvOpen(false)}
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-[#7a8fa8] hover:text-white transition-colors"
                    style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)" }}
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>

              {/* CV Image */}
              <div className="p-4 max-h-[75vh] overflow-y-auto">
                <img src={cvImage} alt="Sanjadul Islam Sun CV" className="w-full rounded-2xl" />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <section
        id="home"
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <FloatingOrb className="w-96 h-96 bg-[#00d4ff] top-20 -left-32 animate-[pulse_6s_ease-in-out_infinite]" />
        <FloatingOrb className="w-80 h-80 bg-[#7c3aed] bottom-20 -right-20 animate-[pulse_8s_ease-in-out_infinite_2s]" />
        <FloatingOrb className="w-64 h-64 bg-[#00d4ff] bottom-40 left-1/3 opacity-10 animate-[pulse_10s_ease-in-out_infinite_4s]" />

        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: "linear-gradient(rgba(0,212,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,1) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto px-6 pt-28 pb-16 flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#00d4ff]/20 bg-[#00d4ff]/5 mb-6"
            >
              <span className="w-2 h-2 rounded-full bg-[#00d4ff] animate-pulse" />
              <span className="text-[#00d4ff] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                Available for work
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-white mb-2"
              style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(2.2rem, 5vw, 4rem)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-0.02em" }}
            >
              Sanjadul Islam
            </motion.h1>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-6"
              style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(2.2rem, 5vw, 4rem)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-0.02em", color: "#00d4ff" }}
            >
              Sun
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-[#7a8fa8] mb-8"
              style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(1rem, 2.5vw, 1.35rem)", fontWeight: 500 }}
            >
              <span className="text-[#00d4ff]">{"// "}</span>
              <TypewriterText texts={roles} />
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-[#7a8fa8] mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed"
              style={{ fontSize: "0.95rem" }}
            >
              Diploma in Engineering student at Mangrove Institute of Science and
              Technology, Khulna. Passionate about crafting stunning digital
              experiences with clean code, beautiful design, and AI-powered solutions.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-wrap gap-4 justify-center lg:justify-start mb-10"
            >
              <a
                href="#projects"
                className="px-7 py-3 rounded-xl text-sm font-semibold text-[#050a14] bg-[#00d4ff] hover:bg-[#33ddff] transition-all duration-200 shadow-[0_0_30px_rgba(0,212,255,0.35)] hover:shadow-[0_0_40px_rgba(0,212,255,0.5)] hover:-translate-y-0.5"
              >
                View My Work
              </a>
              <button
                onClick={() => setCvOpen(true)}
                className="px-7 py-3 rounded-xl text-sm font-semibold text-[#00d4ff] border border-[#00d4ff]/40 hover:bg-[#00d4ff]/10 transition-all duration-200 hover:-translate-y-0.5"
              >
                <Download size={14} className="inline mr-2" />
                Download CV
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="flex gap-4 justify-center lg:justify-start"
            >
              {[
                { icon: Github, href: "https://github.com/sanjadulislam16-lab", label: "GitHub" },
                { icon: Linkedin, href: "https://www.linkedin.com/in/sanjadul-islam-sun-339841401/", label: "LinkedIn" },
                { icon: Mail, href: "mailto:eng.sanjadulislamsun@gmail.com", label: "Email" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-10 h-10 rounded-lg border border-[#00d4ff]/20 bg-[#00d4ff]/5 flex items-center justify-center text-[#7a8fa8] hover:text-[#00d4ff] hover:border-[#00d4ff]/50 hover:bg-[#00d4ff]/10 transition-all duration-200"
                >
                  <Icon size={17} />
                </a>
              ))}
            </motion.div>
          </div>

          {/* Avatar side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
            className="flex-shrink-0"
          >
            <div className="relative w-72 h-72 lg:w-96 lg:h-96">
              <div className="absolute inset-0 rounded-full border border-[#00d4ff]/20 animate-[spin_20s_linear_infinite]">
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#00d4ff]" />
              </div>
              <div className="absolute inset-4 rounded-full border border-[#7c3aed]/20 animate-[spin_15s_linear_infinite_reverse]">
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#7c3aed]" />
              </div>

              <div className="absolute inset-8 rounded-full overflow-hidden border-2 border-[#00d4ff]/30 shadow-[0_0_60px_rgba(0,212,255,0.25),inset_0_0_40px_rgba(0,212,255,0.05)]">
                <img
                  src={myPhoto}
                  alt="Sanjadul Islam Sun"
                  className="w-full h-full object-cover"
                  style={{ objectPosition: "center 15%" }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#00d4ff]/20 to-transparent" />
              </div>

              <motion.div
                animate={{ y: [-6, 6, -6] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -left-4 top-1/4 px-3 py-2 rounded-xl bg-[#0a1628] border border-[#00d4ff]/20 shadow-xl"
              >
                <div className="text-[#00d4ff] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>
                  &lt;/&gt; Dev
                </div>
              </motion.div>
              <motion.div
                animate={{ y: [6, -6, 6] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -right-4 bottom-1/4 px-3 py-2 rounded-xl bg-[#0a1628] border border-[#7c3aed]/30 shadow-xl"
              >
                <div className="text-[#a78bfa] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>
                  🤖 AI Coder
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="text-[#7a8fa8] text-xs" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            scroll down
          </span>
          <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
            <ArrowDown size={16} className="text-[#00d4ff]" />
          </motion.div>
        </motion.div>
      </section>
    </>
  );
}
