import { motion } from "motion/react";
import { ExternalLink, Github, Globe } from "lucide-react";

const projects = [
  {
    title: "E-Commerce Platform",
    description: "A full-stack e-commerce web app with React, Node.js, MongoDB, and Stripe payment integration. Features include product management, cart, orders, and admin dashboard.",
    tags: ["React", "Node.js", "MongoDB", "Stripe"],
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=350&fit=crop&auto=format",
    color: "#00d4ff",
    featured: true,
  },
  {
    title: "UI/UX Design System",
    description: "A comprehensive design system built in Figma with reusable components, tokens, and documentation. Used across multiple client projects.",
    tags: ["Figma", "UI/UX", "Design Tokens"],
    image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=350&fit=crop&auto=format",
    color: "#a78bfa",
    featured: true,
  },
  {
    title: "Task Manager App",
    description: "A cross-platform mobile task management app built with Flutter and Firebase with real-time sync, notifications, and team collaboration features.",
    tags: ["Flutter", "Firebase", "Dart"],
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=600&h=350&fit=crop&auto=format",
    color: "#34d399",
    featured: false,
  },
  {
    title: "AI Chat Interface",
    description: "A sleek AI-powered chat interface built with React and OpenAI API. Features streaming responses, conversation history, and custom prompting.",
    tags: ["React", "OpenAI", "TypeScript"],
    image: "https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=600&h=350&fit=crop&auto=format",
    color: "#f59e0b",
    featured: false,
  },
  {
    title: "Portfolio Dashboard",
    description: "Personal analytics dashboard tracking GitHub activity, project stats, and skill progression with beautiful charts and real-time data.",
    tags: ["Next.js", "Recharts", "REST API"],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=350&fit=crop&auto=format",
    color: "#00d4ff",
    featured: false,
  },
  {
    title: "Restaurant Website",
    description: "A fully animated restaurant website with online reservation system, menu showcase, and CMS integration for easy content management.",
    tags: ["React", "Tailwind", "Node.js"],
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=350&fit=crop&auto=format",
    color: "#f97316",
    featured: false,
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -8, scale: 1.01 }}
      className={`group relative rounded-3xl overflow-hidden ${project.featured ? "md:col-span-2" : ""}`}
      style={{
        background: "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(0,212,255,0.04) 100%)",
        backdropFilter: "blur(24px) saturate(1.8)",
        WebkitBackdropFilter: "blur(24px) saturate(1.8)",
        border: `1px solid ${project.color}20`,
        boxShadow: `0 4px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.08)`,
        transition: "box-shadow 0.3s ease, border-color 0.3s ease",
      }}
    >
      {/* shimmer top */}
      <span className="absolute inset-x-6 top-0 h-px z-10 rounded-full"
        style={{ background: `linear-gradient(90deg, transparent, ${project.color}50, transparent)` }} />

      {/* Image */}
      <div className={`relative overflow-hidden ${project.featured ? "h-56 md:h-64" : "h-48"}`}>
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, transparent 40%, rgba(5,10,20,0.8) 100%)` }} />

        {/* Hover overlay */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4"
          style={{ background: "rgba(5,10,20,0.65)", backdropFilter: "blur(4px)" }}>
          <motion.a
            href="#"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="w-11 h-11 rounded-2xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, rgba(0,212,255,0.5), rgba(0,150,200,0.6))",
              border: "1px solid rgba(0,212,255,0.5)",
              boxShadow: "0 4px 16px rgba(0,212,255,0.3), inset 0 1px 0 rgba(255,255,255,0.2)",
              color: "white",
            }}
          >
            <ExternalLink size={17} />
          </motion.a>
          <motion.a
            href="#"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="w-11 h-11 rounded-2xl flex items-center justify-center"
            style={{
              background: "rgba(255,255,255,0.1)",
              border: "1px solid rgba(255,255,255,0.2)",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,0.15)",
              color: "white",
            }}
          >
            <Github size={17} />
          </motion.a>
        </div>

        {project.featured && (
          <div
            className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold"
            style={{
              fontFamily: "'JetBrains Mono', monospace",
              background: `rgba(255,255,255,0.1)`,
              backdropFilter: "blur(12px)",
              border: `1px solid ${project.color}40`,
              color: project.color,
              boxShadow: "inset 0 1px 0 rgba(255,255,255,0.15)",
            }}
          >
            Featured
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-white font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "1rem" }}>
            {project.title}
          </h3>
          <Globe size={14} className="text-[#7a8fa8] mt-1 flex-shrink-0" />
        </div>
        <p className="text-[#7a8fa8] text-sm leading-relaxed mb-5">{project.description}</p>
        <div className="flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="px-2.5 py-1 rounded-xl text-xs"
              style={{
                fontFamily: "'JetBrains Mono', monospace",
                background: `rgba(255,255,255,0.06)`,
                backdropFilter: "blur(8px)",
                border: `1px solid ${project.color}30`,
                color: project.color,
                boxShadow: "inset 0 1px 0 rgba(255,255,255,0.08)",
              }}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export function Projects() {
  return (
    <section id="projects" className="py-28 relative overflow-hidden">
      <div className="absolute right-0 bottom-0 w-96 h-96 bg-[#00d4ff]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-4 mb-6"
        >
          <span className="text-[#00d4ff] text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>03.</span>
          <h2 className="text-white" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 700 }}>
            My Projects
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-[#00d4ff]/20 to-transparent" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-[#7a8fa8] text-sm mb-14 ml-12"
        >
          A selection of my recent work across web, mobile, and design.
        </motion.p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <ProjectCard key={project.title} project={project} index={i} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <motion.a
            href="https://github.com/sanjadulislam16-lab"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl text-sm relative overflow-hidden"
            style={{
              fontFamily: "'JetBrains Mono', monospace",
              background: "linear-gradient(135deg, rgba(0,212,255,0.12), rgba(124,58,237,0.1))",
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
              border: "1px solid rgba(0,212,255,0.25)",
              color: "#00d4ff",
              boxShadow: "0 4px 20px rgba(0,212,255,0.1), inset 0 1px 0 rgba(255,255,255,0.1)",
            }}
          >
            <span className="absolute inset-x-4 top-0 h-px rounded-full"
              style={{ background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.5), transparent)" }} />
            <Github size={15} />
            View All on GitHub
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
